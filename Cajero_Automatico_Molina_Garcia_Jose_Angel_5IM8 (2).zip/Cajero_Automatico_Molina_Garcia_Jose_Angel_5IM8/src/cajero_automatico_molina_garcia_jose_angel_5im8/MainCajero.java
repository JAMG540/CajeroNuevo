package cajero_automatico_molina_garcia_jose_angel_5im8;


public class MainCajero 
{

    
    public static void main(String[] args) 
    {
        LogicaCajero ejecutar=new LogicaCajero();
    }
    
}
